{
    "HomePage": {
      "heading": "Shopify एप बनाने के लिए अच्छा काम किया गया 🎉",
      "learnMore": "अपने ऐप को बनाने के बारे में और अधिक जानें <ShopifyTutorialLink>इस Shopify ट्यूटोरियल</ShopifyTutorialLink> में 📚",
      "startPopulatingYourApp": "तैयार हैं? अपने ऐप में कुछ नमूना उत्पादों को जमा करना शुरू करें जिसे आप अपने स्टोर में देख सकते हैं और परीक्षण कर सकते हैं।",
      "title": "ऐप नाम",
      "trophyAltText": "Shopify एप बनाने के लिए अच्छा काम",
      "yourAppIsReadyToExplore": "आपका ऐप अन्वेषण के लिए तैयार है! यह आपको शुरू करने के लिए सभी चीजों को प्रदान करता है जिसमें <PolarisLink>Polaris डिज़ाइन सिस्टम</PolarisLink>, <AdminApiLink>Shopify एडमिन API</AdminApiLink>, और <AppBridgeLink>App Bridge</AppBridgeLink> UI पुस्तकालय और घटक शामिल हैं।"
    },
    "NavigationMenu": {
      "pageName": "पृष्ठ नाम"
    },
    "NotFound": {
      "description": "URL की जाँच करें और पुनः प्रयास करें, या आपकी आवश्यकता को पूरा करने के लिए खोज बार का उपयोग करें।",
      "heading": "इस पते पर कोई पृष्ठ नहीं है"
    },
    "PageName": {
      "body": "शरीर",
      "heading": "शीर्षक",
      "primaryAction": "प्राथमिक क्रिया",
      "secondaryAction": "माध्यमिक क्रिया",
      "title": "पृष्ठ नाम"
    },
    "ProductsCard": {
      "description": "नमूना उत्पाद एक डिफ़ॉल्ट शीर्षक और मूल्य के साथ बनाए जाते हैं। आप उन्हें कभी भी हटा सकते हैं।",
      "errorCreatingProductsToast": "उत्पाद बनाने में त्रुटि हुई थी",
      "populateProductsButton": {
        "one": "{{count}} उत्पाद जमाना",
        "other": "{{count}} उत्पाद जमाना"
      },
      "productsCreatedToast": {
        "one": "{{count}} उत्पाद बनाया गया!",
        "other": "{{count}} उत्पाद बनाए गए!"
      },
      "title": "उत्पाद काउंटर",
      "totalProductsHeading": "कुल उत्पाद"
    },
    "AuthLayout": {
      "AuthBanner": {
        "apps@itgeeks": "apps@itgeeks.com",
        "send_message": "संदेश भेजें",
        "project_start": "हर परियोजना एक योजना के साथ शुरू होती है।",
        "itgeeks_mobilify_excellent_product": "ITgeeks Mobilify एक उत्कृष्ट उत्पाद साबित होता है, जो एक निष्ठावान ब्रांड समुदाय को उत्पन्न करने और आवृत्ति से बिक्री को बढ़ाने का एक प्रभावी तरीका प्रदान करता है!",
        "alex_a": "अलेक्स ए"
      },
      "ForgotPassword": {
        "recover_password": "पासवर्ड पुनः प्राप्त करें",
        "mobile_journey": "अपने मोबाइल यात्रा को शुरू करने के लिए लॉग इन करें।"
      }
    },
    
      "Login": {
        "Welcome_back": "वापस स्वागत है",
        "mobile_journey": "अपनी मोबाइल यात्रा में एक और कदम लें!",
        "login": "लॉग इन करें",
        "next": "आगे",
        "signup": "साइन अप करें",
        "forgot_password": "पासवर्ड भूल गए ?"
      },
      "Profile": {
        "alex_doe": "अलेक्स डो",
        "itg_development": "आईटीजी डेवलपमेंट",
        "signout": "साइन आउट",
        "basic_information": "मौलिक जानकारी",
        "update_profile": "प्रोफ़ाइल अपडेट करें",
        "change_password": "पासवर्ड बदलें",
        "com_uppercase_lowercase_letters": "अपना पासवर्ड कम से कम 6 अक्षरों का होना और लोअरकेस और अपरकेस अक्षरों का मिश्रण होना सुनिश्चित करें, साथ ही शंकुओं जैसे #, ?, !, -, और & शामिल हो।",
        "delete_account": "मेरा खाता हटाएं",
        "sitesyncpro_mobile": "साइटसिंकप्रो मोबाइल ऐप चैनल को हटाने से उत्पादों को प्रकाशित करने, आदेश पूरा करने या प्रदर्शन को मूल्यांकित करने की असमर्थता होगी।",
        "delete": "हटाएं"
      },
      "SignUp": {
        "signup": "साइन अप करें",
        "mobile_journey": "अपनी मोबाइल यात्रा में एक और कदम लें!",
        "name_required": "पहला नाम आवश्यक है",
        "email_valid": "ईमेल मान्य होनी चाहिए",
        "phonenumber_required": "फ़ोन नंबर आवश्यक है",
        "next": "आगे",
        "login": "लॉग इन",
        "forgot_password": "पासवर्ड भूल गए ?"
      },
      "StoreDetails": {
        "store_details": "स्टोर विवरण",
        "mobile_journey": "अपनी मोबाइल यात्रा में एक और कदम लें!",
        "signup": "साइन अप करें"
      },
      "Header": {
        "days_trial_left": "बचे हुए दिन परीक्षण",
        "upgrade": "अब अपग्रेड करें",
        "auto_save": "स्वचालित सहेजें",
        "preview": "पूर्वावलोकन",
        "save": "सहेजें"
      },
      "LayoutWrapper": {
        "DesktopSizeIndication": {
          "use_desktop": "अपने ऐवेदन को डिज़ाइन करने के लिए डेस्कटॉप का उपयोग करें",
          "to_continue_designing": "अपने शानदार ऐप के डिज़ाइन को जारी रखने के लिए",
          "desktop_device": "डेस्कटॉप डिवाइस का उपयोग करें। आप मोबाइल पर धक्कड़ को बजाने और चैट बातचीत प्रबंधित कर सकते हैं।"
        },
        "ProjectMainPage": {
          "it_geeks": "आईटीजीक्स",
          "mobilify": "मोबाइलफाई"
        }
      },
      "Preview": {
        "install_itgeeks": "आईटीजीक्स मोबाइलफाई एडमिन ऐप इंस्टॉल करें:",
        "ios": "iOS: इसे एप्पल ऐप स्टोर से प्राप्त करें",
        "store": "स्टोर।",
        "Android_download": "एंड्रॉयड: इसे",
        "play_store": "गूगल प्ले स्टोर से डाउनलोड करें।",
        "scan-qrcode": "क्यूआर कोड स्कैन करें:",
        "app_look": "ऐप खोलें और क्यूआर कोड",
        "scanner": " स्कैनर खोजें।",
        "scan_provided_qrcode": "आपके ऐप का पूर्वावलोकन करने के लिए दिए गए क्यूआर कोड को स्कैन करें।",
        "preview_app": "पूर्वावलोकन।"
      },
      "Analytics": {
        "visitors": "वर्तमान में आगंतुक",
        "analyticsnumber": "235",
        "add_cart": "कार्ट में जोड़ें कुल",
        "analyticsdoller": "$43908.00",
        "app_sales": "ऐप बिक्री",
        "analyticsdoller2": "$50290.00",
        "app_orders": "कुल ऐप आदेश",
        "app_users": "कुल ऐप उपयोगकर्ता",
        "analyticsnumber2": "2305",
        "popular_products": "सबसे लोकप्रिय उत्पाद",
        "product": "उत्पाद",
        "inventory": "इन्वेंटरी",
        "earning": "कमाई",
        "orders": "आदेश",
        "views": "दृश्य"
      },
      "AppSeetings": {
        "customize": "कस्टमाइज़ करें",
        "app_icon": "ऐप आइकन",
        "png_jpg": "PNG और JPG छवि: 1024x1024, 32-बिट, ≤ 2MB",
        "logo_required": "लोगो आवश्यक है",
        "launch_img": "लॉन्च इमेज",
        "png_jpg_2": "PNG और JBG छवि: 1242x2688, 32-बिट, ≤ 5MB",
        "upload_img": "छवि अपलोड करने के लिए क्लिक करें",
        "splash_screen": "स्प्लैश स्क्रीन आवश्यक है",
        "app_name": "ऐप नाम",
        "name_required": "ऐप_नाम आवश्यक है",
        "enable_loader": "लोडर सक्षम करें",
        "submit": "प्रस्तुत"
      },
      "AppSettingHome": {
        "launch_img": "लॉन्च इमेज",
        "loading": "लोड हो रहा है"
      },
      
        "Chat": {
          "start_chat": "चैट शुरू करें "
        },
        "WelcomeWinChat": {
          "welcome_chat": "स्वागत है!"
        },
        "DateRangeInput": {
          "schedule_timing": "शेड्यूल समय के लिए तिथियों का चयन करें",
          "days": "दिन",
          "from": "से",
          "to": "तक",
          "submit": "प्रस्तुत"
        },
        "Design": {
          "add_section": "अनुभाग जोड़ें"
        },
        "InputComponent": {
          "upload_img": "छवि अपलोड करने के लिए क्लिक करें"
        },
        "AddSectionBlock": {
          "select_form": "फ़ॉर्म का चयन करें"
        },
        "CollectionGrid": {
          "collection_grid": "संग्रह ग्रिड",
          "title": "शीर्षक"
        },
        "CountDownTimer": {
          "count_timer": "गिनती टाइमर",
          "time": "07 : 15 : 11 : 38"
        },
        "DiscountSection": {
          "discount_section": "छूट अनुभाग",
          "clear_cloth": "साफ कपड़ा @ $199 | 71% छूट | $699",
          "read_more": "अधिक पढ़ें"
        },
        "Divider": {
          "divider": "विभाजक"
        },
        "Form": {
          "form": "फ़ॉर्म"
        },
        "IconWithText": {
          "icon_text": "प्रतीक साथ पाठ",
          "column": "स्तंभ",
          "lorem_dummy_text": "लोरेम इप्सम बस सिम्पली डमी टेक्स्ट है…"
        },
        "ImageBannerSlider": {
          "img_banner_slider": "छवि बैनर स्लाइडर"
        },
        "ImageComparison": {
          "image_comparison": "छवि तुलना",
          "before": "पहले",
          "after": "बाद"
        },
        "ImageWithText": {
          "image_text": "छवि के साथ पाठ"
        },
        "InstagramFeed": {
          "insta_feed": "इंस्टाग्राम फ़ीड"
        },
        "ProductGrid": {
          "product_grid": "उत्पाद ग्रिड",
          "product_title": "उत्पाद शीर्षक",
          "product_price": "$19.00"
        },
        "ScrollingText": {
          "scroll_text": "स्क्रोलिंग पाठ",
          "shipping_orders": "🚚 $100 से अधिक सभी आदेशों पर मुफ्त शिपिंग"
        },
        "Search": {
          "Search": "खोज"
        },
        "Testimonials": {
          "testimonials": "प्रशंसापत्र"
        },
        "Video": {
          "video": "वीडियो"
        },
        "Blocks": {
          "header": "हैडर"
        },
        "CollectionGridEditor": {
          "collection_grid": "संग्रह ग्रिड",
          "switch_slider": "स्लाइडर पर स्विच करें",
          "schedule_time": "समय निर्धारित करें",
          "rows": "पंक्तियाँ",
          "itm": "आइटम",
          "columns": "स्तंभ",
          "view_all": "सभी को देखें सक्षम करें",
          "select_collection": "संग्रह का चयन करें",
          "select": "चुनें",
          "add_block": "ब्लॉक जोड़ें"
        },
        "Comparison": {
          "image_comparison": "छवि तुलना"
        },
        "Count_Down_Timer": {
          "count_timer": "गिनती टाइमर"
        },
        "CustomizationView": {
          "customize_app": "अपने ऐप को अनुकूलित करें",
          "section_block_sidebar": "शुरू करने के लिए साइडबार में एक अनुभाग या ब्लॉक का चयन करें।",
          "grow_business": "अपना व्यापार बढ़ाएं",
          "customizing_theme": "अगर आप अपने थीम को अनुकूलित करने में मदद चाहते हैं, तो आप एक ऐप विशेषज्ञ को किराए पर ले सकते हैं।",
          "customize": "संपर्क करें",
          "app_sales": "ऐप बिक्री",
          "customization_price": "$50290.00",
          "app_orders": "कुल ऐप आदेश",
          "customization_number": "540",
          "app_users": "कुल ऐप उपयोगकर्ता"
        
      
    },
    
        "Discount": {
          "description": "विवरण"
        },
        "DividerEditor": {
          "divider": "विभाजक",
          "space": "अंतर",
          "px": "पिक्सेल",
          "manage_range": "दो खंडों के बीच अंतर को कम और बढ़ाने के लिए रेंज का प्रबंधन करें।",
          "thickness": "मोटाई",
          "select_color": "रंग चुनें"
        },
        "EditorDisable": {
          "curtomize_app": "अपने ऐप को अनुकूलित करें",
          "select_section": "शुरू करने के लिए एक अनुभाग या ब्लॉक चुनें",
          "sidebar": "साइडबार।",
          "grow_business": "अपना व्यापार बढ़ाएं",
          "customizing": "अगर आपको अपने",
          "app_expert": "थीम को अनुकूलित करने में मदद चाहिए, तो आप एक ऐप विशेषज्ञ को किराए पर ले सकते हैं।",
          "contact_us": "हमसे संपर्क करें",
          "add_cart": "कार्ट में जोड़ें कुल",
          "editor_disable": "$43908.00",
          "app_sales": "ऐप बिक्री",
          "app_orders": "कुल ऐप आदेश",
          "editor_number": "540",
          "app_users": "कुल ऐप उपयोगकर्ता"
        },
        "HeaderStyle": {
          "header": "हैडर",
          "logo_width": "लोगो चौड़ाई",
          "menu_icon": "मेनू आइकन",
          "hide_menu_icon": "मेनू आइकन छिपाएं",
          "user_icon": "उपयोगकर्ता आइकन",
          "hide_user_icon": "उपयोगकर्ता आइकन छिपाएं",
          "cart_icon": "कार्ट आइकन",
          "hide_cart_icon": "कार्ट आइकन छिपाएं",
          "bottom_navigation": "निचली नेविगेशन सक्षम करें"
        },
        "IconEdit": {
          "icon_text": "प्रतीक साथ पाठ",
          "schedule_time": "समय निर्धारित करें",
          "image_banner": "छवि बैनर",
          "description": "विवरण",
          "add_block": "ब्लॉक जोड़ें"
        },
        "ImageBanner": {
          "img_banner_slider": "छवि बैनर स्लाइडर",
          "auto_slides": "ऑटो स्विच स्लाइड",
          "change_slides": "हर बदलाव के लिए स्लाइड बदलें",
          "second": "सेकंड",
          "schedule_time": "समय निर्धारित करें",
          "select": "चुनें",
          "image_banner": "छवि बैनर",
          "add_block": "ब्लॉक जोड़ें"
        },
        "ImageWithTextEditor": {
          "image_text": "छवि के साथ पाठ",
          "schedule_time": "समय निर्धारित करें",
          "select": "चुनें"
        },
        "InstagramFeedEditor": {
          "insta_feed": "इंस्टाग्राम फ़ीड",
          "connect_instagram": "अपने इंस्टाग्राम को कनेक्ट करें",
          "select": "चुनें",
          "columns": "स्तंभों की संख्या",
          "rows": "पंक्तियों की संख्या",
          "post": "पोस्ट"
        },
        "ProductGridEditor": {
          "product_grid": "उत्पाद ग्रिड",
          "switch_slider": "स्लाइडर पर स्विच करें",
          "schedule_time": "समय निर्धारित करें",
          "select": "चुनें",
          "rows": "पंक्तियों की संख्या",
          "itm": "आइटम",
          "column": "स्तंभों की संख्या",
          "view_all": "सभी को देखें सक्षम करें",
          "collection_products": "यदि संग्रह में दिखाए गए से अधिक उत्पाद हैं",
          "add_block": "ब्लॉक जोड़ें"
        },
        "ScrollingTextEditor": {
          "scroll_text": "स्क्रॉलिंग पाठ",
          "scroll_speed": "स्क्रॉलिंग की गति",
          "second": "सेकंड",
          "schedule_time": "समय निर्धारित करें",
          "Select": "चुनें",
          "add_block": "ब्लॉक जोड़ें"
        },
        "SearchEditor": {
          "search": "खोज",
          "preffix_icon": "प्रीफिक्स आइकन",
          "suffix_icon": "सूफ़िक्स आइकन"
        },
        "TestimonisalsEditor": {
          "testimonials": "प्रशंसापत्र",
          "schedule_time": "समय निर्धारित करें",
          "quote": "उद्धरण",
          "add_block": "ब्लॉक जोड़ें"
        },
        "VideoEditor": {
          "video": "वीडियो",
          "heading": "शीर्षक",
          "schedule_time": "समय निर्धारित करें",
          "select": "चुनें",
          "url": "यूआरएल",
          "vimeo_url": "एक YouTube या Vimeo यूआरएल का उपयोग करें",
          "auto_play": "ऑटोप्ले",
          "video_automatically": "वीडियो स्वचालित रूप से म्यूट हो जाता है जब ऑटोप्ले का उपयोग किया जाता है।",
          "vidoe_alt": "वीडियो वैकल्पिक पाठ",
          "screen_readers": "स्क्रीन रीडर का उपयोग करने वाले ग्राहकों के लिए वीडियो का विवरण दें।"
        },
        "ProductList": {
          "select": "चुनें"
        },
        "CheckBox": {
          "checkbox": "चेक बॉक्स",
          "label": "लेबल"
        },
        "DropDown": {
          "drop_down": "ड्रॉप डाउन",
          "select": "चुनें"
        },
        "InputField": {
          "input_field": "इनपुट फ़ील्ड",
          "label": "लेबल"
        },
        "Radio": {
          "radio": "रेडियो",
          "label": "लेबल",
          "option1": "विकल्प 1",
          "option2": "विकल्प 2"
        },
        "Switch": {
          "switch": "स्विच",
          "label": "लेबल"
        },
        "FormBlocks": {
          "form_name": "फ़ॉर्म का नाम",
          "button_text": "बटन पाठ"
        },
        "FormBuildSection": {
          "add_field": "फ़ील्ड जोड़ें"
        },
        "FromViewHome": {
          "save_form": "फ़ॉर्म सहेजें"
        },
        "ButtonComponent": {
          "button": "बटन"
        },
        "CheckBoxComponent": {
          "checkbox": "चेक बॉक्स"
        },
        "DefaultFormEditor": {
          "form_details": "फ़ॉर्म विवरण",
          "form_description": "फ़ॉर्म विवरण"
        },
        "DropDownComponent": {
          "option_list": "विकल्प सूची:",
          "label": "लेबल:",
          "value": "मूल्य:",
          "name_required": "विकल्प नाम जोड़ने के लिए आवश्यक है",
          "value_required": "मूल्य आवश्यक है और यह अनूठा होना चाहिए",
          "click_add": "जोड़ने के लिए क्लिक करें"
        },
        "InputFieldComponent": {
          "input_field": "इनपुट फ़ील्ड"
        },
        "RadioComponent": {
          "radio": "रेडियो",
          "option_list": "विकल्प सूची:",
          "name_required": "विकल्प नाम जोड़ने के लिए आवश्यक है",
          "value_required": "मूल्य आवश्यक है और यह अनूठा होना चाहिए",
          "click_add": "जोड़ने के लिए क्लिक करें"
        },
        "SwitchComponent": {
          "switch": "स्विच"
        },
        "FormItem": {
          "view_answer": "उत्तर देखें"
        },
        "FormTable": {
          "delete_confirmation": "हटाने की पुष्टि",
          "delete_form": "कृपया पुष्टि करें कि आप इस फ़ॉर्म को हटाना चाहते हैं? यह क्रिया पूर्ववत नहीं की जा सकती है।",
          "confirm": "पुष्टि करें",
          "form_builder": "फ़ॉर्म बिल्डर",
          "create_manage_forms": "अपने फ़ॉर्मों को आसानी से बनाएं और प्रबंधित करें।",
          "create_form": "फ़ॉर्म बनाएं",
          "create_new_form": "नया फ़ॉर्म बनाएं",
          "click_button": "डाटा कलेक्ट करना शुरू करने के लिए उपर दाएँ कोने में बटन पर क्लिक करें।"
        },
        "MenuPopUp": {
          "remove_item": "आइटम हटाएं",
          "remove_this_item": "क्या आप इस आइटम को हटाना चाहते हैं?",
          "remove": "हटाएं"
        },
        "MenuSideBar": {
          "navigation": "नेविगेशन",
          "main_menu": "डिफ़ॉल्ट मेन्यू चयन (मुख्य मेन्यू)",
          "menu_stream_line": "नेविगेशन मेन्यू स्ट्रीमलाइन आइकन: https://streamlinehq.com"
        },
        "SidePopUp": {
          "name": "मूल्य",
          "select_icon": "आइकन चुनें"
        },
        "CountDownTimerMobileView": {
          "super_deals": "सुपर डील्स 🔥"
        },
        "DiscountScreen": {
          "read_more": "और पढ़ें"
        },
        "HeaderMobileView": {
          "clean": "साफ़"
        },
        "ImageComparisonMobileView": {
          "before": "पहले",
          "after": "बाद"
        },
        
            "InstagramFeedMobileView": {
              "@clean": "@साफ़"
            },
            "ProductGridMobileView": {
              "view_all": "सभी देखें"
            },
            "TestimonialsMobileView": {
              "previous": "पिछला",
              "next": "अगला"
            },
            "VideoMobileView": {
              "add_url": "URL जोड़ें.."
            },
            "AutomaticNotification": {
              "data_not_fount": "डेटा नहीं मिला",
              "customize": "कस्टमाइज़"
            },
            "CreateNotification": {
              "notification": "सूचना",
              "title_required": "शीर्षक आवश्यक है",
              "message": "संदेश",
              "message_required": "संदेश आवश्यक है",
              "type_required": "प्रकार आवश्यक है",
              "image_required": "छवि आवश्यक है",
              "shopify_segments": "शॉपिफाई सेगमेंट्स",
              "delivery": "प्रसव",
              "send_immedite": "तुरंत भेजें",
              "schedule_later": "बाद में निर्धारित करें",
              "time_required": "समय आवश्यक है",
              "date_required": "तिथि आवश्यक है",
              "timezone_required": "समय क्षेत्र आवश्यक है",
              "sent_notification": "सूचना भेजी गई",
              "reset": "रीसेट",
              "notication_success": "सूचना सफलतापूर्वक भेजी गई!",
              "notification_route": "आपकी सूचनाएं मार्ग पर हैं।",
              "ok": "ठीक है"
            },
            "NotificationHeader": {
              "sent_notification": "सूचना भेजी गई",
              "schedule_notification": "निर्धारित सूचना",
              "automatic_notification": "स्वचालित सूचना",
              "total": "कुल",
              "notification": "सूचनाएं",
              "sent": "भेजी गई",
              "scheduled": "निर्धारित",
              "auto": "स्वचालित",
              "create_auto_notification": "स्वचालित सूचना बनाएं",
              "create_notification": "सूचना बनाएं"
            },
            "ScheduleNotification": {
              "data_not_found": "डेटा नहीं मिला",
              "schedule_date": "निर्धारित तिथि",
              "time_zone": "समय क्षेत्र"
            },
            "SentNotification": {
              "invalid_date": "अमान्य तिथि",
              "data_not_found": "डेटा नहीं मिला",
              "sent": "भेजी गई",
              "clicks": "क्लिक्स",
              "success_rate": "सफलता दर"
            },
            "NotificationHomeView": {
              "itgeeks_mobilify": "ITGEEKS MOBILIFY",
              "android": "एंड्रॉयड"
            },
            "CustmizePopUp": {
              "type_required": "प्रकार आवश्यक है",
              "title_12_char": " शीर्षक 12 वर्ण लंबा होना चाहिए",
              "message": "संदेश",
              "message_22_char": "संदेश 22 वर्ण लंबा होना चाहिए",
              "select_segment": "सेगमेंट चुनें",
              "save_apply": "सहेजें और लागू करें"
            },
            "Plan": {
              "plan_pricing": "योजनाएँ और मूल्य",
              "monthly_plan": "मासिक योजना",
              "yearly_plan": "वार्षिक योजना",
              "tenpercentoff": "10% छूट",
              "trial_active": "परीक्षण सक्रिय",
              "active": "सक्रिय",
              "unsubscrible": "सदस्यता रद्द करें",
              "enable_30_trial": "30 दिनों की परीक्षण सक्रिय करें",
              "unsubscribe_plan": "क्या आप वास्तव में योजना को रद्द करना चाहते हैं?",
              "confirm_unsubscribe_plan": "कृपया पुष्टि करें कि आप इस योजना को रद्द करना चाहते हैं?",
              "confirm": "पुष्टि करें",
              "plan_incorporates": "प्रत्येक योजना में शामिल है",
              "inquiries": "क्या आपके पास अभी भी प्रश्न हैं?",
              "found_information": "यदि आपने जो जानकारी चाहिए, उसे नहीं पाया है, तो हमारी मददगार टीम के साथ चैट करें।",
              "get_touch": "संपर्क में रहें"
            },
            "Plugins": {
              "store_plugins": "स्टोर प्लगइन्स",
              "enable": "सक्षम करें",
              "how_enable": "कैसे सक्षम करें"
            },
            "FireBaseForm": {
              "email_required": "ईमेल आईडी आवश्यक है"
            },
            "GoogleAnalyticsForm": {
              "email_required": "ईमेल आईडी आवश्यक है"
            },
            "InstaForm": {
              "clientid_required": "ग्राहक आईडी आवश्यक है",
              "secretkey_required": "सीक्रेट कुंजी आवश्यक है",
              "redirect_required": "रीडायरेक्ट यूआरआई आवश्यक है"
            },
            "JudgeMeForm": {
              "clientid_required": "ग्राहक आईडी आवश्यक है",
              "secretkey_required": "सीक्रेट कुंजी आवश्यक है",
              "redirect_required": "रीडायरेक्ट यूआरआई आवश्यक है"
            },
            "PluginPopUp": {
              "enable": "सक्षम करें"
            },
            "WhatsappForm": {
              "token_required": "पहुँच टोकन आवश्यक है",
              "appid_required": "ऐप आईडी आवश्यक है",
              "businessid_required": "व्यापार आईडी आवश्यक है"
            },
            "YotpoForm": {
              "clientid_required": "ग्राहक आईडी आवश्यक है",
              "secretkey_required": "सीक्रेट कुंजी आवश्यक है"
            },
            
                "ZipCodeForm": {
                  "token_required": "एक्सेस टोकन आवश्यक है"
                },
                "AppStatus": {
                  "app_status": "ऐप स्थिति",
                  "check_currentstatus": "अपने ऐप की वर्तमान स्थिति की जांच करें",
                  "development_updates": "विकास अपडेट",
                  "link_android": "एंड्रॉयड के लिए लिंक",
                  "link_ios": "आईओएस के लिए लिंक"
                },
                "ContactUs": {
                  "contact_us": "हमसे संपर्क करें",
                  "better_consult": "हमसे संपर्क करके बेहतर सलाह लें",
                  "response_list": "प्रतिक्रिया सूची",
                  "your_informations": "आपकी जानकारी",
                  "email": "ईमेल",
                  "phone_number": "फ़ोन नंबर",
                  "address": "पता",
                  "submit": "सबमिट",
                  "name": "नाम",
                  "number": "नंबर",
                  "message": "संदेश",
                  "resp_available": "प्रदर्शित करने के लिए कोई प्रतिक्रियाएं उपलब्ध नहीं हैं"
                },
                "MyProfile": {
                  "alex_doe": "अलेक्स डो",
                  "itg_development": "आईटीजी डेवलपमेंट",
                  "sign_out": "साइन आउट",
                  "basic_information": "मौलिक जानकारी",
                  "update_profile": "प्रोफ़ाइल अपडेट करें",
                  "change_password": "पासवर्ड बदलें",
                  "regexcharacters": "अपने पासवर्ड को कम से कम 6 वर्णों की लंबाई का होना और छोटे और बड़े अक्षरों, साथ ही #, ?, !, -, और & जैसे प्रतीक का एक संयोजन होना सुनिश्चित करें।",
                  "delete_account": "मेरा खाता हटाएं",
                  "sitesyncpro_mobile": "SiteSyncPro मोबाइल ऐप चैनल को हटाने से उत्पादों को प्रकाशित करने, आदेश पूरा करने या प्रदर्शन की प्रदर्शिता की असमर्थता होगी।",
                  "delete": "हटाएं"
                },
                "PrivacyPolicy": {
                  "privacy_policy": "गोपनीयता नीति",
                  "more": "अधिक",
                  "more_explore": "अधिक जो आप जानना चाहेंगे"
                },
                "ReturnReplace": {
                  "ret_repalce_policy": "वापसी प्रतिस्थापन नीति",
                  "update": "अपडेट"
                },
                "StoreList": {
                  "store_list": "स्टोर सूची",
                  "provid_inputs": "स्टोर को सूचीबद्ध करने के लिए इनपुट प्रदान करें",
                  "store_inform": "स्टोर सूचनाएँ",
                  "app_name": "ऐप का नाम",
                  "short_desc": "संक्षेपित विवरण",
                  "long_desc": "लंबा विवरण",
                  "keywords": "कीवर्ड्स",
                  "support_mobile": "मोबाइल समर्थन",
                  "support_email": "ईमेल समर्थन",
                  "privacy_policy": "गोपनीयता नीति यूआरएल",
                  "terms_condition": "मैं नियम और शर्तों से सहमत हूँ।",
                  "submit": "सबमिट"
                },
                "TermsUse": {
                  "terms_uses": "उपयोग की शर्तें",
                  "update": "अपडेट"
                },
                "Index": {
                  "redirect": "रीडायरेक्ट हो रहा है..."
                },
                "Settings": {
                  "settings": "सेटिंग्स",
                  "upgrade": "अब अपग्रेड करें",
                  "setup": "सेटअप करें"
                },
                "CurrentFormat": {
                  "currency_format": "मुद्रा प्रारूप",
                  "currency_symbol": "मुद्रा प्रतीक",
                  "submit": "सबमिट"
                },
                "MinContentVal": {
                  "min_contain_val": "न्यूनतम विषय समाहिति मूल्य",
                  "submit": "सबमिट"
                },
                "SelectLanguage": {
                  "select_language": "भाषा चुनें",
                  "submit": "सबमिट"
                },
                "SelectOneLanguage": {
                  "select_language": "भाषा चुनें",
                  "submit": "सबमिट"
                },
                "DiscountCodeOne": {
                  "new_discount": "नया डिस्काउंट कोड",
                  "available_pricerule": "उपलब्ध मूल्य नियम",
                  "type": "प्रकार",
                  "amount": "राशि",
                  "start_date": "प्रारंभ तिथि",
                  "exp_date": "समाप्ति तिथि",
                  "discount_code": "डिस्काउंट कोड",
                  "add_discode": "डिस्काउंट कोड जोड़ें",
                  "start_new_pricerule": "नए मूल्य नियम के साथ शुरू करें"
                },
                "DiscountCodeTwo": {
                  "new_discount": "नया डिस्काउंट कोड",
                  "active_discode": "सक्रिय डिस्काउंट कोड",
                  "type": "प्रकार",
                  "amount": "राशि",
                  "start_date": "प्रारंभ तिथि",
                  "exp_date": "समाप्ति तिथि",
                  "auto_change": "स्वचालित रूप से लागू करें पर परिवर्तन",
                  "delete": "हटाएं"
                },
                "PriceRule": {
                  "pricerule_discode": "डिस्काउंट कोड के साथ मूल्य नियम बनाएं",
                  "discode": "डिस्काउंट कोड :",
                  "start_date": "प्रारंभ तिथि :",
                  "end_date": "अंतिम तिथि :",
                  "value_type": "मूल्य प्रकार :",
                  "fixed_amount": "स्थिर राशि",
                  "percentage": "प्रतिशत",
                  "value": "मूल्य :",
                  "submit": "सबमिट"
                },
                "AddFont1": {
                  "snas_serif": "स्नस सेरीफ़",
                  "serif": "सेरीफ़",
                  "select": "चयन करें"
                },
                "AddFonts": {
                  "snas_serif": "स्नस सेरीफ़",
                  "serif": "सेरीफ़",
                  "select": "चयन करें"
                },
                "StyleSettings": {
                  "style": "स्टाइल",
                  "headings_text": "शीर्षक पाठ",
                  "change": "बदलें",
                  "body_text": "शरीर पाठ",
                  "colors": "रंग",
                  "general": "सामान्य",
                  "primary_button": "प्राथमिक बटन",
                  "secondary_button": "माध्यमिक बटन",
                  "side_navbar": "साइड नेविगेशन",
                  "sideNav_unselectcolor": "साइड नेविगेशन अचयन रंग",
                  "bottom_navbar": "नीचे का नेविगेशन",
                  "edit_text": "पाठ संपादित करें"
                },
                "SupportFaq": {
                  "contact_us": "हमसे संपर्क करें",
                  "setup_call": "कॉल सेटअप करें",
                  "app@itg.com": "apps@itgeeks.com",
                  "faq": "अक्सर पूछे जाने वाले प्रश्न",
                  "itgeeks_mobilify_fingertips": " बिल्कुल! ITGeeks Mobilify सुनता है कि यह तकनीकी दुनिया को आपके हाथों में लाने के बारे में सबकुछ है। यहां आपके एफएक्यू खंड के लिए एक ड्राफ़्ट है:"
                },
                "SupportForm": {
                  "this_form": "यह फॉर्म है",
                  "content": "सामग्री",
                  "submit_request": "एक अनुरोध सबमिट करें",
                  "team_members": "आप नीचे से हमारे अनुकूल ग्राहक सफलता टीम के सदस्यों में से किसी से संपर्क कर सकते हैं। किसी विषय का चयन करके आरंभ करें जिसमें हम आपकी सहायता कर सकते हैं।",
                  "start_here": "यहाँ से शुरू करें",
                  "hi_whathelp": "हाय, हम आपकी किस तरह सहायता कर सकते हैं?",
                  "detailed_description": "एक विस्तृत विवरण प्रदान करें",
                  "information_details": " बिल्कुल! जिस जानकारी या विवरण को आप मुझसे साझा करना चाहते हैं, उसे साझा करें और मैं आपकी मदद करने के लिए अपनी सर्वोत्तम कोशिश करूंगा। बस याद रखें कि इसे गोपनीय और उचित सीमाओं के भीतर रखें।",
                  "relevant_url": "एक प्रासंगिक यूआरएल शामिल करें",
                  "randomsequence_letters": " ऐसा लगता है कि आपने एक यादृच्छिक अक्षरों का एक यादृच्छिक क्रम दर्ज किया है। क्या आप कुछ विशेष टाइप करना चाहते थे या कोई विशेष प्रश्न है? मुझे बताएं कि मैं आपकी कैसे मदद कर सकता हूं!",
                  "attachments": "अटैचमेंट्स",
                  "dragdrop_file": "यहाँ अपलोड या ड्रैग एंड ड्रॉप फ़ाइलें करें",
                  "submit": "सबमिट"
                },
                "Theme": {
                  "themes": "थीम्स",
                  "select_theme": "अपने स्मार्टफोन एप्लिकेशन के लिए एक थीम चुनें।",
                  "restore_default": "डिफ़ॉल्ट पुनर्स्थापित करें",
                  "clean": "साफ़",
                  "fashion_suitable": "फैशन उपयुक्त",
                  "customize": "कस्टमाइज़",
                  "upgrade_now": "अब अपग्रेड करें",
                  "view_demo": "डेमो देखें",
                  "try_theme": "थीम का प्रयास करें",
                  "glow_theme": "चमक थीम",
                  "beauty_theme": "सौंदर्य उपयुक्त थीम",
                  "shopify_api_key": "आपका ऐप SHOPIFY_API_KEY पर्यावरण चर मूल्य सेट किए बिना चल रहा है। कृपया यह सुनिश्चित करें कि यह जब रीऐक्ट ऐप चलाने या बनाने के लिए सेट है।",
                  "partners_dashboard": "आपके ऐप केवल तब लोड हो सकता है जब URL में <b>होस्ट</b> आर्ग्यूमेंट हो। कृपया सुनिश्चित करें कि यह सेट है, या <b>पार्टनर डैशबोर्ड</b> का उपयोग करके अपना ऐप एक्सेस करें <b>अपने ऐप का परीक्षण करें</b> सुविधा"
                },
                "Demo": {
                  "fetch_data": "डेटा प्राप्त करें"
                }
              }
              
          
          
      
      

    
  